# Arduino_SNMP
SNMP Agent built with Arduino

This is a very rough-around-the-edges SNMP Agent library I created for personal use.
Originally designed on the ESP8266 Arduino Core, it is very Heap-Intensive and is not nice to memory.
Not sure how it will work on basic Arduinos.

It does let you pass in any UDP Client though, so it theoretically will work in any network environment.

Pull requests/comments are welcome
